




//
//  LSView.m
//  home
//
//  Created by liusong on 2019/3/24.
//  Copyright © 2019 liusong. All rights reserved.
//

#import "LSView.h"
#import "LSMine.h"
#import "LSPodObject.h"

@implementation LSView
- (instancetype)initWithFrame:(CGRect)frame{
    if (self=[super initWithFrame:frame]) {
        self.backgroundColor=[UIColor orangeColor];
    }
    return self;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
