//
//  setting.h
//  setting
//
//  Created by liusong on 2019/3/25.
//  Copyright © 2019 liusong. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for setting.
FOUNDATION_EXPORT double settingVersionNumber;

//! Project version string for setting.
FOUNDATION_EXPORT const unsigned char settingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <setting/PublicHeader.h>


