//
//  ViewController.m
//  LSAppiPhone
//
//  Created by liusong on 2019/3/24.
//  Copyright © 2019 liusong. All rights reserved.
//

#import "ViewController.h"
#import "LSPodObject.h"
#import "LSView.h"
#import "LSMine.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [LSMine new];
    [LSMine new];
}


@end
