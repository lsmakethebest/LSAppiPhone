//
//  AppDelegate.h
//  LSAppiPhone
//
//  Created by liusong on 2019/3/24.
//  Copyright © 2019 liusong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

