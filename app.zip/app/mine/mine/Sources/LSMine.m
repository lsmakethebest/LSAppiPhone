


//
//  LSMine.m
//  mine
//
//  Created by liusong on 2019/3/25.
//  Copyright © 2019 liusong. All rights reserved.
//

#import "LSMine.h"
#import "LSView.h"
//#import "LSPodObject.h"

@implementation LSMine
-(instancetype)init
{
    if (self = [super init]) {
        [LSView new];
    }
    return self;
}
@end
