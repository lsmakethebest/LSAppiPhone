//
//  LSMine.h
//  mine
//
//  Created by liusong on 2019/3/25.
//  Copyright © 2019 liusong. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSMine : NSObject

@end

NS_ASSUME_NONNULL_END
